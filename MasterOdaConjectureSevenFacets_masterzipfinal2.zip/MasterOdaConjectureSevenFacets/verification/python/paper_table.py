"""Write the LaTeX of the certificate table of the paper (Appendix A) from data/certificates.txt.

Usage: python3 paper_table.py certificates.txt            print the table
       python3 paper_table.py certificates.txt main.tex   check that main.tex contains it

The table lists, for the double blowups of Z_a and W_{a,b}, every pair of centres whose
certificate differs from the most frequent one of its family, and the certificates of the
families F, G and C.
"""
import re
import sys
from collections import Counter, OrderedDict

BEGIN = "% BEGIN TABLE"
END = "% END TABLE"


def centre(s):
    m = re.fullmatch(r"pt\((\d+),(\d+),(\d+)\)", s)
    if m:
        return "p_{%s%s%s}" % m.groups()
    m = re.fullmatch(r"cv\((\d+),(\d+)\)", s)
    if m:
        return "c_{%s%s}" % m.groups()
    raise ValueError(s)


def cert(kind, xs):
    v = "(%s)" % ",".join(xs)
    return {"S": "S", "P": "P", "P2": "Q"}[kind] + v


def read(path):
    rows = []
    for line in open(path):
        t = line.split()
        if t:
            rows.append(t)
    return rows


def table(path):
    rows = read(path)
    out = [BEGIN]
    for fam, name in (("Z", "Z_a"), ("W", "W_{a,b}")):
        fr = [r for r in rows if r[0] == fam]
        certs = [cert(r[3], r[4:]) for r in fr]
        default, nd = Counter(certs).most_common(1)[0]
        groups = OrderedDict()
        for r, c in zip(fr, certs):
            if c != default:
                groups.setdefault(c, []).append("%s\\,%s" % (centre(r[1]), centre(r[2])))
        out.append("\\paragraph{Double blowups of $%s$ (%d pairs).} The certificate is "
                   "$%s$ for %d pairs; the other pairs are:" % (name, len(fr), default, nd))
        out.append("\\begin{itemize}")
        for c in sorted(groups, key=lambda c: (-len(groups[c]), c)):
            items = groups[c]
            out.append("\\item $%s$ (%d pairs): $%s$." % (c, len(items), "$, $".join(items)))
        out.append("\\end{itemize}")
    fr = [r for r in rows if r[0] == "F"]
    certs = sorted({cert(r[2], r[3:]) for r in fr})
    out.append("\\paragraph{Blowups of $F_{a,p}$ (%d centres).} The certificate is $%s$ for every centre."
               % (len(fr), "$, $".join(certs)))
    g = [r for r in rows if re.fullmatch(r"G[0-3]", r[0])]
    out.append("\\paragraph{The fans $G^j_{a,p}$.} %s." % "; ".join(
        "$G^%s$: $%s$" % (r[0][1], cert(r[1], r[2:])) for r in g))
    c = [r for r in rows if r[0] == "C"][0]
    out.append("\\paragraph{The fan $C_a$.} $%s$." % cert(c[1], c[2:]))
    out.append(END)
    return "\n".join(out) + "\n"


def main():
    t = table(sys.argv[1])
    if len(sys.argv) == 2:
        sys.stdout.write(t)
        return 0
    s = open(sys.argv[2]).read()
    i, j = s.find(BEGIN), s.find(END)
    if i < 0 or j < 0 or s[i:j + len(END) + 1] != t:
        print("paper table differs from data/certificates.txt", file=sys.stderr)
        return 1
    print("paper table: matches data/certificates.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
